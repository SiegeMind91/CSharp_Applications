﻿using System;

namespace WhereAmI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting GeoCoordinate Watcher...");

            // 1. Add a Reference to System.Device.dll

            // 2. Use the GeoCoordinate Watcher

            // 3. Use the Map Image REST API

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
