﻿using System;

namespace FaceDetect
{
    class Program
    {
        static void Main(string[] args)
        {
            // Command Line Arguments

            // HTTP Request

            // Load Image

            // Submit the Image to HTTP endpoint

            // Inspect JSON

            // Draw rectangles on the image (copy)
        }
    }
}
